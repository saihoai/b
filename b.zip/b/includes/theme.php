<?php

if( !function_exists( 'happytore_vc_gitem_template_attribute_post_meta_value' ) )
{
	function happytore_vc_gitem_template_attribute_post_meta_value( $value, $data )
	{
		/**
		 * @var null|Wp_Post $post ;
		 * @var string $data ;
		 */
		extract( array_merge( array(
			'post' => null,
			'data' => '',
		), $data ) );

		if( isset( $post->{$data} ) )
		{

			if( preg_match( '/post_content/', $data ) )
			{
				ob_start();
				do_action( 'b_post_custom_css', $post->ID );
				$css = ob_get_clean();
				return  apply_filters( 'the_content', $post->post_content . $css );		
			}

			return $post->{$data};
		}

		if( preg_match( '/post_date--/', $data ) )
		{
			list ($k, $f) = explode( '--', $data );
			if( isset( $post->{$k} ) )
			{
				$formats = explode( '_', $f );
				$text = '';

				foreach( $formats as $format )
				{
					$text .= "<span class='{$format}'>" . get_the_time( $format, $post->ID ) . "</span>";
				}

				if( !empty( $text ) )
				{
					return $text;
				}
			}			
		}

		if( preg_match( '/post_excerpt--/', $data ) )
		{
			list ($k, $f) = explode( '--', $data );
			if( isset( $post->{$k} ) )
			{
				return wp_trim_words( apply_filters( 'the_excerpt', get_the_excerpt() ), $f);
			}			
		}

		if( $data == 'vc_price' && function_exists( 'WC' ) && function_exists( 'wc_get_product' ) )
		{
			require_once WC()->plugin_path() . '/includes/abstracts/abstract-wc-product.php';
			$p = wc_get_product( $post->ID );
				
			if( $p )
			{

				if( function_exists( 'wc_get_template' ) )
				{
					ob_start();
					global $product;
					$product = $p;
					wc_get_template( 'loop/price.php' );
					return ob_get_clean();
				}
				else
				{
					return '<span class="price">' . $p->get_price_html() . '</span>';
				}
			}
		}

		if( $data == 'vc_gallery' && function_exists( 'WC' ) && function_exists( 'wc_get_product' ) )
		{
			require_once WC()->plugin_path() . '/includes/abstracts/abstract-wc-product.php';
			$p = wc_get_product( $post->ID );
				
			if( $p )
			{

				if( function_exists( 'wc_get_template' ) )
				{
					ob_start();
					global $product;
					$product = $p;
					wc_get_template( 'single-product/product-thumbnails.php' );
					return ob_get_clean();
				}
				else
				{
					$product = $p;
					$output = '';
					$attachment_ids = $product->get_gallery_image_ids();

					if ( $attachment_ids && has_post_thumbnail() ) {
						foreach ( $attachment_ids as $attachment_id ) {
							$full_size_image = wp_get_attachment_image_src( $attachment_id, 'full' );
							$thumbnail       = wp_get_attachment_image_src( $attachment_id, 'shop_thumbnail' );
							$image_title     = get_post_field( 'post_excerpt', $attachment_id );

							$attributes = array(
								'title'                   => $image_title,
								'data-src'                => $full_size_image[0],
								'data-large_image'        => $full_size_image[0],
								'data-large_image_width'  => $full_size_image[1],
								'data-large_image_height' => $full_size_image[2],
							);

							$html  = '<div data-thumb="' . esc_url( $thumbnail[0] ) . '" class="woocommerce-product-gallery__image"><a href="' . esc_url( $full_size_image[0] ) . '">';
							$html .= wp_get_attachment_image( $attachment_id, 'shop_single', false, $attributes );
					 		$html .= '</a></div>';

							$output .= apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, $attachment_id );
						}
						return $output;
					}
				}
			}
		}

		if( $data == 'vc_discount' && function_exists( 'WC' ) && function_exists( 'wc_get_product' ) )
		{
			require_once WC()->plugin_path() . '/includes/abstracts/abstract-wc-product.php';
			$p = wc_get_product( $post->ID );
				
			if( $p )
			{

				$product = $p;
					
				if ( $product->is_on_sale() )
				{
					$text = apply_filters( 'woocommerce_sale_flash', '<span class="onsale">' . esc_html__( 'Sale!', 'woocommerce' ) . '</span>', $post, $product );
					if( preg_match( '/\d+%/', $text, $match ) )
					{
						$text = str_replace( '%', '', $match[0] );
						$text = "<span class='onsale'>{$text}<span>%</span></span>";
					}

					return $text;
				}
			}
		}

		if( $data == 'vc_cate' && function_exists( 'WC' ) && function_exists( 'wc_get_product' ) && function_exists( 'wc_get_product_category_list' ) )
		{
			require_once WC()->plugin_path() . '/includes/abstracts/abstract-wc-product.php';
			$p = wc_get_product( $post->ID );
				
			if( $p )
			{

				return wc_get_product_category_list( $post->ID, '', '', '' );
			}
		}

		if( $data == 'vc_addtocart' && function_exists( 'WC' ) && function_exists( 'wc_get_product' ) )
		{
			require_once WC()->plugin_path() . '/includes/abstracts/abstract-wc-product.php';
			$p = wc_get_product( $post->ID );
			global $product;
			$product = $p;
			$id = rand(0, 1000);
			$product_type = $product->get_type();
			$path = str_replace( '/b/includes/', '/yith-essential-kit-for-woocommerce-1/modules/yith-woocommerce-colors-labels-variations/', plugin_dir_path( __FILE__ ) );
				
			if( $p )
			{
				ob_start();
				echo '<div data-id="p-' . $id . '">';
				if( $product_type != 'variable' )
				{
					do_action( 'woocommerce_' . $product_type . '_add_to_cart' );
				}
				else
				{

					$attributes = $product->get_variation_attributes();

					/**
			         * Get an array of types and values for each attribute
			         *
			         * @access public
			         * @since 1.0.0
			         */
		            global $wpdb;
		            $types = array();

		            if( !empty($attributes) ) {
		                foreach( $attributes as $name => $options ) {
		                    $attribute_name = substr($name, 3);
		                    $attribute = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "woocommerce_attribute_taxonomies WHERE attribute_name = '$attribute_name'");
		                    if ( isset( $attribute ) ) {
		                        $types[$name] = $attribute->attribute_type;
		                    }
		                    else {
		                        $types[$name] = 'select';
		                    }
		                }
		            }

		            // get default attributes
		            $selected_attributes = is_callable( array( $product, 'get_default_attributes' ) ) ? $product->get_default_attributes() : $product->get_variation_default_attributes();

		            /** FIX WOO 2.1 */
		            $wc_get_template = function_exists('wc_get_template') ? 'wc_get_template' : 'woocommerce_get_template';

		            // Load the template
		            $wc_get_template( 'single-product/add-to-cart/variable-wccl.php', array(
		                'available_variations'  => $product->get_available_variations(),
		                'attributes'   			=> $attributes,
		                'selected_attributes' 	=> $selected_attributes,
		                'attributes_types'      => $types
		            ), '', $path . 'templates/' );
	            }


				echo '</div>';
				echo '
				<script>
				(function( a ) {
					var 
						d = a( \'[data-id="p-'. $id . '"]\'),
						g = d.find(".variations_form")
					;
                	g.wc_variation_form(),
	                g.trigger("check_variations"),
	                "undefined" != typeof a.fn.yith_wccl && g.yith_wccl(),
	                "undefined" != typeof a.fn.prettyPhoto && d.find("a[data-rel^=\'prettyPhoto\'], a.zoom").prettyPhoto({
	                    hook: "data-rel",
	                    social_tools: !1,
	                    theme: "pp_woocommerce",
	                    horizontal_padding: 20,
	                    opacity: .8,
	                    deeplinking: !1
	                });
	                a( document ).delegate( d, "woocommerce_variation_has_changed", function() {
	                	var wrap = g.closest( ".product-new" );
	                	wrap.find( ".vc_gitem-woocommerce-product-price_html" ).html( wrap.find( ".woocommerce-variation-price .price" ).html() );
	                } )
				} )(jQuery);
				</script>
				';
				return ob_get_clean();
			}
		}

		return strlen( $data ) > 0 ? get_post_meta( $post->ID, $data, true ) : $value;
	}
}
add_filter( 'vc_gitem_template_attribute_post_meta_value', 'happytore_vc_gitem_template_attribute_post_meta_value', 11, 2 );

if( !function_exists( 'b_vc_shortcodes_css_class' ) )
{
	function b_vc_shortcodes_css_class( $class_to_filter, $tag, $atts )
	{
		if( $tag == 'vc_text_separator' && isset( $atts[ 'css' ] ) && preg_match( '/border-bottom-width/', $atts[ 'css' ] ) )
		{
			$class_to_filter .= ' vc_separator_border_bottom-true';
		}
		return $class_to_filter;
	}
}
add_filter( 'vc_shortcodes_css_class', 'b_vc_shortcodes_css_class', 11, 3 );

if( !function_exists( 'b_section' ) )
{
	function b_section( $k = 'h_s' )
	{
		$h = get_theme_mod( $k, 0 );
		$post   = get_post( $h );
		$content = apply_filters( 'the_content', $post->post_content );
		
		do_action( 'b_post_custom_css', $post->ID );

		$re = array(
			'/data-vc-post-id="\d+"/' 			=> 'data-vc-post-id="'.$post->ID.'"',
			'/&quot;page_id&quot;:\d+,&quot;/' 	=> '&quot;page_id&quot;:'.$post->ID.',&quot;'
		);
		foreach( $re as $k => $v )
		{
			$content = preg_replace( $k, $v, $content );
		}

		echo $content;
	}
}
add_action( 'b_section', 'b_section' );


if( !function_exists( 'b_sb_data' ) )
{
	function b_sb_data( $name = 'sidebar-1' )
	{
		if( isset( $_GET[ 'sb' ] ) )
		{
			if( $_GET[ 'sb' ] == 'l' )
			{
				return array( 'w' => 3, 'p' => 'left' );	
			}
			elseif( $_GET[ 'sb' ] == 'r' )
			{
				return array( 'w' => 3, 'p' => 'right' );	
			}
			return false;
		}
		
		if( $name == 'sidebar-1' )
		{
			$p = get_theme_mod( 'b_sb_p', 'none' );
			$w = intval( get_theme_mod( 'b_sb_w', 3 ) );

			if( $p != 'none' )
			{
				return array( 'w' => $w, 'p' => $p );
			}
			else
			{
				return false;
			}
		}
		else if( $name == 'sidebar-2' )
		{
			$p = get_theme_mod( 's_sb_p', 'none' );
			$w = intval( get_theme_mod( 's_sb_w', 3 ) );

			if( $p != 'none' )
			{
				return array( 'w' => $w, 'p' => $p );
			}
			else
			{
				return false;
			}
		}
		return false;
	}
}
add_filter( 'b_sb_data', 'b_sb_data' );

if( !function_exists( 'b_sb_name' ) )
{
	function b_sb_name( $sb = '' )
	{
		return str_replace( 'sidebar-', '', $sb );
	}
}
add_filter( 'b_sb_name', 'b_sb_name' );

if( !function_exists( 'b_row_start' ) )
{
	function b_row_start( $sb = 'sidebar-1' )
	{
		if ( !is_active_sidebar( $sb )  )
		{
			return false;
		}
		$data_w = apply_filters( "b_sb_data", $sb );

		if( !is_array( $data_w ) )
		{
			return false;
		}
		$w1 = $data_w[ 'w' ];
		$w2 = 12 - $w1;

		if( $data_w[ 'p' ] == 'right' )
		{
			$t = $w1;
			$w1 = $w2;
			$w2 = $t;
		}
		echo "<div class='row has-sb'><div class='col-md-{$w1}'>";

		if( $data_w[ 'p' ] == 'left' )
		{
			get_sidebar( apply_filters( 'b_sb_name', $sb ) );
			echo "</div><div class='col-md-{$w2}'>";
		}
	}
}
add_action( 'b_row_start', 'b_row_start' );

if( !function_exists( 'b_row_end' ) )
{
	function b_row_end( $sb = 'sidebar-1' )
	{
		if ( !is_active_sidebar( $sb )  )
		{
			return false;
		}
		$data_w = apply_filters( "b_sb_data", $sb );
		if( !is_array( $data_w ) )
		{
			return false;
		}
		$w1 = $data_w[ 'w' ];
	
		echo "</div>";

		if( isset( $data_w[ 'p' ] ) && $data_w[ 'p' ] == 'right' )
		{
			echo "<div class='col-md-{$w1}'>";
				get_sidebar( apply_filters( 'b_sb_name', $sb ) );
			echo "</div>";
		}
		echo "</div>";
	}
}
add_action( 'b_row_end', 'b_row_end' );

if( !function_exists( 'b_post_social' ) )
{
	function b_post_social()
	{
		$url = get_the_permalink();
		$title = esc_url( get_the_title() );
		$output = "<div class='post-social'>";
			$output .= "<span>" . esc_html__( 'Share:', 'b' ) . "</span>";
			$output .= "<a href='https://www.facebook.com/sharer/sharer.php?u={$url}'><i class='fa fa-facebook'></i></a>";
			$output .= "<a href='https://twitter.com/home?status={$url}'><i class='fa fa-twitter'></i></a>";
			$output .= "<a href='https://plus.google.com/share?url={$url}'><i class='fa fa-google-plus'></i></a>";
			$output .= "<a href='https://www.linkedin.com/shareArticle?mini=true&url={$url}&title={$title}&summary=&source='><i class='fa fa-linkedin'></i></a>";
			$output .= "<a href='https://pinterest.com/pin/create/button/?url={$url}&media=&description='><i class='fa fa-pinterest'></i></a>";
		$output .= "</div>";
		echo $output;
	}
}
add_action( 'b_post_social', 'b_post_social' );




if( !function_exists( 'b_rtl_mode' ) )
{
	function b_rtl_mode()
	{
  		if( is_rtl() )
		{
			wp_deregister_script( 'wpb_composer_front_js' );
			wp_dequeue_script( 'wpb_composer_front_js' );
			
			wp_enqueue_style( 'happystore-css-composer-rtl', plugins_url( '/a/c/rtl.js_composer.min.css', __DIR__ ) );
			wp_enqueue_script( 'happystore-js-composer-rtl', plugins_url( '/a/js/rtl.js_composer_front.min.js', __DIR__ ), array( 'jquery' ), '20160816', true );
		}
  	}
}
add_action( 'b_rtl_mode', 'b_rtl_mode' );

if( !function_exists( 'b_cdn_mode' ) )
{
	function b_cdn_mode()
	{
		wp_enqueue_style( 'font-awesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', array(), '4.7.0' );
		/*wp_enqueue_style( 'magnific-popup-1.1.0', 'https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css', array(), '3.4.1' );
		wp_enqueue_script( 'magnific-popup-1.1.0', 'https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js', array( 'jquery' ), '20160816', true );

		wp_enqueue_style( 'slick', '//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.css', array(), '1.6.0' );
		wp_enqueue_style('ultimate-style-min');
		wp_enqueue_script( 'slick', '//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.min.js', array( 'jquery' ), '20160816', true );*/
	}
}
add_action( 'b_cdn_mode', 'b_cdn_mode' );


if( !function_exists( 'b_remove_head_scripts' ) )
{
	function b_remove_head_scripts() 
	{ 
	   	remove_action('wp_head', 'wp_print_scripts'); 
	   	remove_action('wp_head', 'wp_print_head_scripts', 9); 
	   	remove_action('wp_head', 'wp_enqueue_scripts', 1);

	   	wp_deregister_style( 'vc_pageable_owl-carousel-css' );
	   	wp_deregister_style( 'animate-css' );

	   	if( function_exists( 'vc_asset_url' ) && defined( 'WPB_VC_VERSION' ) )
	   	{
		   	wp_register_style( 'vc_pageable_owl-carousel-css', vc_asset_url( 'lib/owl-carousel2-dist/assets/owl.min.css' ), array(), WPB_VC_VERSION );
			wp_register_style( 'animate-css', vc_asset_url( 'lib/bower/animate-css/animate.min.css' ), array(), WPB_VC_VERSION );
		}

	   	add_action('wp_footer', 'wp_print_scripts', 5);
	   	add_action('wp_footer', 'wp_enqueue_scripts', 5);
	   	add_action('wp_footer', 'wp_print_head_scripts', 5); 
	} 
}
//add_action( 'wp_enqueue_scripts', 'b_remove_head_scripts' );

if( !function_exists( 'b_filter_scripts' ) )
{
	function b_filter_scripts( $content = '' )
	{
		preg_match_all( '/<script[^>]*>(.*?)<\/script>/sim', $content, $rs );

		if( count( $rs[0] ) == 0 )
		{
			return $content;
		}
		foreach( $rs[0] as $item )
		{
			$content = str_replace( $item, '', $content );
		}
		wp_enqueue_script( 'happystore-inline', plugins_url( '/a/js/customizer.js', __DIR__ ), array( 'jquery' ) );
   		foreach( $rs[1] as $item )
		{
			wp_add_inline_script( 'happystore-inline', $item );
		}
		return $content;
	}
}
//add_filter( 'the_content', 'b_filter_scripts', 200 );

if( !function_exists( 'b_filter_styles' ) )
{
	function b_filter_styles( $content = '' )
	{
		preg_match_all( '/<style[^>]*>(.*?)<\/style>/sim', $content, $rs );

		if( count( $rs[0] ) == 0 )
		{
			return $content;
		}
		foreach( $rs[0] as $item )
		{
			$content = str_replace( $item, '', $content );
		}
		do_action( 'b_put_css', implode( "\n", $rs[1] ) );
		return $content;
	}
}
add_filter( 'the_content', 'b_filter_styles', 200 );

if( !function_exists( 'b_pro_the_content' ) )
{
	function b_pro_the_content( $content = '' )
	{
		$arr = array(
			'moz' => '',
			'webkit' => '',
			'id="_wpnonce_new_activity_comment"' => '',
			'role="complementary"' => '',
			'id="today"' => '',
			'id="next"' => '',
			'id="prev"' => '',
			'id="wp-calendar"' => '',
			'id="recentcomments"' => '',
			'aria-required="true"' => '',
			'role="navigation"' => '',
			"allowfullscreen" => '',
			"frameborder='0'" => '',
			'id="attachment_612"' => '',
			'for="billing_state"' => '',
			'for="shipping_state"' => '',
			'id="_wpnonce"' => '',
			'placeholder=""' => '',
			'aria-required="true"' => '',
			'itemprop="breadcrumb"' => '',
			'cellspacing="0"' => '',
			"target=''" => '',
			'frameborder="0"' => '',
			'scrolling="no"' => '',
			'id=""' => '',
			'itemprop="url"' => '',
			'itemprop="logo"' => '',
			'"custom-logo"' => '"img-responsive navbar-brand"',
			'<p></div>' => '</div>',
			'style=>' => 'style>',
			'"data-tooltip-ba' => '" data-tooltip-ba',
			'"data-tooltip-of' => '" data-tooltip-of',
			'data- data-token' => 'data-token',
			'action=""' => 'action="'.esc_url( home_url( '/' ) ) .'"',
			'<dt class="wp-caption-dt"></dt>' => '',
			'<big' => '<span class="tag-big"',
			'<tt' => '<span class="tag-tt"',
			'<acronym' => '<abbr',
			'acronym>' => 'abbr>',
			'big>' => 'span>',
			'tt>' => 'span>',
			'widivh' => 'width',
			'"" class="ult_pricing_heading"' => '" class="ult_pricing_heading"',
			'<div " data-ultimate-target' => '<div data-ultimate-target',
			'"line-height":""}\' " class="' => '"line-height":""}\' class="',
			'id="page_in_widget-' => 'data-id="page_in_widget-',
			'"data-bhcolor' => '" data-bhcolor',
			'id="button-click-overlay"' => 'data-id="button-click-overlay"',
			'<h2 class="widgettitle"></h2>' => '',
			'id="woocommerce_widget_cart-2"' => '',
			'href = ""' => '',
			'xmlns:v' => 'data-xmlns-v',
			'value=""  selected=\'selected\'' => 'value=""',
			'cellspacing="0"' => '',
			'id="b-e' => 'data-id="b-e',
			'id="b-f-' => 'data-id="b-f-',
			'id="b-s-' => 'data-id="b-s-',
			'id="b-h-' => 'data-id="b-h-',
			'id="slide-13-layer-' => 'data-id="slide-13-layer-',
			'id="slide-14-layer-' => 'data-id="slide-14-layer-',
			'id="slide-15-layer-' => 'data-id="slide-15-layer-',
			'id="slide-16-layer-' => 'data-id="slide-16-layer-',
			'id="slide-17-layer-' => 'data-id="slide-17-layer-',
			'id="slide-18-layer-' => 'data-id="slide-18-layer-',
			'id="slide-19-layer-' => 'data-id="slide-19-layer-',
			'id="slide-20-layer-' => 'data-id="slide-20-layer-',
			'id="slide-21-layer-' => 'data-id="slide-21-layer-',
			'id="slide-22-layer-' => 'data-id="slide-22-layer-',
			'id="slide-23-layer-' => 'data-id="slide-23-layer-',
			'rel="v:url"' => '',
			'property="v:title"' => '',
			' id="yith-wcwl-messages"' => ' data-id="yith-wcwl-messages"',
			' id="yith-wcwl-form"' => ' data-id="yith-wcwl-form"',
			' id="yith-wcwl-row' => ' data-id="yith-wcwl-row',
			' id="yith_wcwl_edit_wishlist"' => ' data-id="yith_wcwl_edit_wishlist"',
			' id="yith_wcwl_form_nonce"' => ' data-id="yith_wcwl_form_nonce"',
			'placeholder="State / county"' => 'data-placeholder="State / county"',
			'<section class="shipping-calculator-form" style="display:none;">' => '<section class="shipping-calculator-form" style="display:none;"><h5 class="hidden">&nbsp;</h5>',
			'class="select "  data-' => 'class="select "',
			'"data-icncolor="' => '" data-icncolor="',
			'"data-ihover="' => '" data-ihover="',
			'"data-height="' => '" data-height="',
			'"data-cntbg="' => '" data-cntbg="',
			'"data-headerbg="' => '" data-headerbg="',
			'"data-headerhove' => '" data-headerhove',
			'"data-title="' => '" data-title="',
			'"data-newtitle="' => '" data-newtitle="',
			'"data-icon="' => '" data-icon="',
			'"data-newicon="' => '" data-newicon="',
			'"data-activeicon' => '" data-activeicon',
			'"data-effect="' => '" data-effect="',
			'"data-override="' => '" data-override="',
			'"data-activetitl' => '" data-activetitl',
			'"data-activebg="' => '" data-activebg="',
			'"data-img=""data' => '" data-img="" data',
			'"data-texthover=' => '" data-texthover=',
			'"data-cnthvrbg="' => '" data-cnthvrbg="',
			'"data-trigger="' => '" data-trigger="',
			'"data-arrowposit' => '" data-arrowposit',
			'"}\' " class' => '"}\' class',
			'"data-style="' => '" data-style="',
			'"data-bgcolor="' => '" data-bgcolor="',
			'"data-bghover="' => '" data-bghover="',
			'id="ult-range-slider "' => 'id="ult-range-slider"',
			"'data-title-back" => "' data-title-back",
			'autocomplete' => 'data-autocomplete',
			'autofocus' => 'data-autofocus',
		);
		foreach( $arr as $k => $v )
		{
			$content = str_replace( $k, $v, $content );
		}

		return $content;
	}
}
add_filter( 'the_content', 'b_pro_the_content', 20000 );

if( !function_exists( 'b_woocommerce_dropdown_variation_attribute_options_html' ) )
{
	function b_woocommerce_dropdown_variation_attribute_options_html( $html = '' )
	{
		return str_replace( '"" data-show_option_none', '" data-show_option_none', $html );
	}
}
add_filter( 'woocommerce_dropdown_variation_attribute_options_html', 'b_woocommerce_dropdown_variation_attribute_options_html' );

if( !function_exists( 'b_remove_api' ) )
{
	function b_remove_api() 
	{
		remove_action( 'wp_head', 'feed_links_extra', 3 ); //Extra feeds such as category feeds
		remove_action( 'wp_head', 'feed_links', 2 ); // General feeds: Post and Comment Feed
		remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links', 10 );
	}
}
add_action( 'after_setup_theme', 'b_remove_api' );

if( !function_exists( 'b_comment_form_fields' ) )
{
	function b_comment_form_fields( $fields = array() )
	{
		foreach( $fields as $name => $field )
		{
			$fields[ $name ] = str_replace( 'aria-required="true"', '', $field );
		}
		return $fields;
	}
}
add_filter( 'comment_form_fields', 'b_comment_form_fields' );

if( !function_exists( 'b_navigation_markup_template' ) )
{
	function b_navigation_markup_template( $template = '' )
	{
		return str_replace( 'role="navigation"', '', $template );
	}
}
add_filter( 'navigation_markup_template', 'b_navigation_markup_template' );

if( !function_exists( 'b_comment_list' ) )
{
	function b_comment_list( $text = '' )
	{
		$text = str_replace( 'class="comment-body">', 'class="comment-body"><h5 class="hidden">&nbsp;</h5>', $text );
		return $text;
	}
}
add_filter( 'b_comment_list', 'b_comment_list' );

if( !function_exists( 'b_post_related' ) )
{
	function b_post_related()
	{
		$post_id = get_the_ID();
		echo do_shortcode( "[related_posts_by_tax post_id='{$post_id}' posts_per_page='3' format='thumbnails' image_size='medium']" );
	}
}
add_action( 'b_post_related', 'b_post_related' );

if( !function_exists( 'b_related_posts_by_taxonomy_caption' ) )
{
	function b_related_posts_by_taxonomy_caption( $caption = '', $post )
	{
		$post_content = $post->post_excerpt ? $post->post_excerpt : $post->post_content;
		$post_content = apply_filters( 'the_content', $post_content );
		$post_content = wp_trim_words( wp_kses( $post_content, array() ), 50 );
		$post_link = get_the_permalink( $post );
		$text = "<span class='post_title'>{$post->post_title}</span>";
		$text .= "<span class='post_content'>{$post_content}</span>";
		$text .= "<a class='post_link' href='{$post_link}'><i class='fa fa-long-arrow-right' aria-hidden='true'></i></a>";
		return $text;
	}
}
add_filter( 'related_posts_by_taxonomy_caption', 'b_related_posts_by_taxonomy_caption', 10, 2 );

if( !function_exists( 'b_remove_register_form' ) )
{
	function b_remove_register_form( $text = '' )
	{
		if( is_user_logged_in() )
		{
			$text = str_replace( '[woocommerce_simple_registration]', '', $text );
		}
		return $text;
	}
}
add_filter( 'the_content', 'b_remove_register_form' );














