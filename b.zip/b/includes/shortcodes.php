<?php 
if( !function_exists( 'sh_title' ) )
{
	function sh_title( $sep = '&raquo;', $display = false, $seplocation = '' ) 
	{
	    global $wp_locale;
	 
	    $m        = get_query_var( 'm' );
	    $year     = get_query_var( 'year' );
	    $monthnum = get_query_var( 'monthnum' );
	    $day      = get_query_var( 'day' );
	    $search   = get_query_var( 's' );
	    $title    = '';
	 
	    $t_sep = '%WP_TITLE_SEP%'; // Temporary separator, for accurate flipping, if necessary
	 
	    // If there is a post
	    if ( is_single() || ( is_home() && ! is_front_page() ) || ( is_page() && ! is_front_page() ) ) {
	        $title = single_post_title( '', false );
	    }
	 
	    // If there's a post type archive
	    if ( is_post_type_archive() ) {
	        $post_type = get_query_var( 'post_type' );
	        if ( is_array( $post_type ) ) {
	            $post_type = reset( $post_type );
	        }
	        $post_type_object = get_post_type_object( $post_type );
	        if ( ! $post_type_object->has_archive ) {
	            $title = post_type_archive_title( '', false );
	        }
	    }
	 
	    // If there's a category or tag
	    if ( is_category() || is_tag() ) {
	        $title = single_term_title( '', false );
	    }
	 
	    // If there's a taxonomy
	    if ( is_tax() ) {
	        $term = get_queried_object();
	        if ( $term ) {
	            $tax   = get_taxonomy( $term->taxonomy );
	            $title = single_term_title( $tax->labels->name . $t_sep, false );
	        }
	    }
	 
	    // If there's an author
	    if ( is_author() && ! is_post_type_archive() ) {
	        $author = get_queried_object();
	        if ( $author ) {
	            $title = $author->display_name;
	        }
	    }
	 
	    // Post type archives with has_archive should override terms.
	    if ( is_post_type_archive() && $post_type_object->has_archive ) {
	        $title = post_type_archive_title( '', false );
	    }
	 
	    // If there's a month
	    if ( is_archive() && ! empty( $m ) ) {
	        $my_year  = substr( $m, 0, 4 );
	        $my_month = $wp_locale->get_month( substr( $m, 4, 2 ) );
	        $my_day   = intval( substr( $m, 6, 2 ) );
	        $title    = $my_year . ( $my_month ? $t_sep . $my_month : '' ) . ( $my_day ? $t_sep . $my_day : '' );
	    }
	 
	    // If there's a year
	    if ( is_archive() && ! empty( $year ) ) {
	        $title = $year;
	        if ( ! empty( $monthnum ) ) {
	            $title .= $t_sep . $wp_locale->get_month( $monthnum );
	        }
	        if ( ! empty( $day ) ) {
	            $title .= $t_sep . zeroise( $day, 2 );
	        }
	    }
	 
	    // If it's a search
	    if ( is_search() ) {
	        /* translators: 1: separator, 2: search phrase */
	        $title = sprintf( __( 'Search Results %1$s %2$s' ), $t_sep, strip_tags( $search ) );
	    }
	 
	    // If it's a 404 page
	    if ( is_404() ) {
	        $title = __( 'Page not found' );
	    }

	    $title = explode( '%WP_TITLE_SEP%', $title );
	    $title = array_shift( $title );
	 
	    // Send it out
	    if ( $display ) {
	        echo $title;
	    } else {
	        return $title;
	    }
	}
}


if( !function_exists( 'sh_yoast_breadcrumb' ) )
{
	function sh_yoast_breadcrumb()
	{
		if ( function_exists('yoast_breadcrumb') ) 
		{
			$text = do_shortcode( '<div class="row"><div class="col-sm-6"><div class="breadcrumbs">[wpseo_breadcrumb]</div></div><div class="col-sm-6 hidden-xs"><div class="p-t">###page_title###</div></div></div>' );
			$title = sh_title();

			if( function_exists( 'get_post_type' ) && get_post_type() )
			{
				$post_type = get_post_type_object( get_post_type() );

				if( function_exists( 'is_product' ) && is_product() == get_the_ID() )
				{
					$text = str_replace( $title, get_the_title( wc_get_page_id( 'shop' ) ), $text );
				}
				else if( function_exists( 'is_shop' ) && is_shop() )
				{
					$text = str_replace( $title, get_the_title( wc_get_page_id( 'shop' ) ), $text );
				}
				else
				{
					$text = str_replace( $title, $post_type->label, $text );
				}

				if( is_single() )
				{
					if( get_post_type() == 'post' )
					{
						$title = esc_html__( 'Blog detail', 'b' );
					}
					else if( is_product() )
					{
						$title = esc_html__( 'Product detail', 'b' );
					}
				}
				$text = str_replace( '###page_title###', $title, $text );
			}
			else
			{
				$text = str_replace( '###page_title###', '', $text );
			}
		 
			return $text;
		}
		return '';
	}
}
add_shortcode( 'sh_yoast_breadcrumb', 'sh_yoast_breadcrumb' );

if( !function_exists( 'b_compare' ) )
{
	function b_compare()
	{
		global $yith_woocompare, $wpdb;

		if( !$yith_woocompare )
		{
			return false;
		}

		if( !$yith_woocompare->obj )
		{
			return false;
		}

		if( !method_exists( $yith_woocompare->obj, 'get_products_list' ) )
		{
			return false;
		}
		
		$products = $yith_woocompare->obj->get_products_list();
		$plugin_path  = untrailingslashit( plugin_dir_path( __DIR__ ) )  . '/t/compare/';
		$atts_field = array_diff_assoc($yith_woocompare->obj->fields(), $yith_woocompare->obj->default_fields );
		$atts_field = array_merge(
			array( 
				'weight'        => __( 'Weight', 'b' ),
                'dimensions'    => __( 'Dimensions', 'b' )
            ), 
        	$atts_field 
        );

        $fields = array(
			'name' => esc_html__( 'ITEMS', 'b' ),
			'rating' => esc_html__( 'Rating', 'b' ),
			'price' => esc_html__( 'UNIT PRICE', 'b' ),
			'desc' => esc_html__( 'Description', 'b' ),
			'status' => esc_html__( 'availability', 'b' ),
		);
		$action_field = array(
			'qty' => esc_html__( 'quantity', 'b' ),
			'actions' => esc_html__( 'actions', 'b' ),
		);
		$fields = array_merge( $fields, $atts_field, $action_field );
		$att_keys = array_keys( $atts_field );

		if( count( $products ) > 0 )
		{
			ob_start();
			require( $plugin_path . 'view.php' );
			return ob_get_clean();
		}
		else
		{
			ob_start();
			require( $plugin_path . 'view-empty.php' );
			return ob_get_clean();
		}
	}
}
add_shortcode( 'b_compare', 'b_compare' );







