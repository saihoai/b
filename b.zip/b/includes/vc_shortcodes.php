<?php

if( !function_exists( 'b_vc_set_shortcodes_templates_dir' ) )
{
	function b_vc_set_shortcodes_templates_dir()
	{
		if( function_exists( 'vc_set_shortcodes_templates_dir' ) )
		{
  			vc_set_shortcodes_templates_dir( untrailingslashit( plugin_dir_path( __DIR__ ) )  . '/t/vc' );
  		}
  	}
}
add_action( 'after_setup_theme', 'b_vc_set_shortcodes_templates_dir' );

if( !function_exists( 'sh_vc_google_fonts_get_fonts_filter' ) )
{
	function sh_vc_google_fonts_get_fonts_filter( $arr = array() )
	{
		if( is_array( $arr ) )
		{
			$arr[] = (object)array(
				'font_family' => 'Poppins',
				'font_styles' => '300,regular,500,600,700',
				'font_types' => '300 light regular:300:normal,400 regular:400:normal,500 bold regular:500:normal,600 bold regular:600:normal,700 bold regular:700:normal',
			);
		}
		return $arr;
	}
}
add_filter( 'vc_google_fonts_get_fonts_filter', 'sh_vc_google_fonts_get_fonts_filter', 100 );

if( !function_exists( 'sh_pc_integrateWithVC' ) )
{
	function sh_pc_integrateWithVC() 
	{
		$display = array(
			__( 'Title', 'b' ) => 'title',
			__( 'Link', 'b' ) => 'link',
			__( 'Excerpt with title', 'b' ) => 'excerpt',
			__( 'Excerpt only (no title)', 'b' ) => 'excerpt-only',
			__( 'Content', 'b' ) => 'content',
			__( 'All (includes custom fields)', 'b' ) => 'all',
		);

		vc_map( array(
			"name" => __( "Page Content", "b" ),
			"base" => "insert",
			"class" => "",
			"category" => __( "Content", "b"),
			"params" => array(
				array(
					"type" => "autocomplete",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Page ID", "b" ),
					"param_name" => "page",
					"value" => '0',
					'settings' => array(
						'multiple' => false,
						'sortable' => true,
						'groups' => true,
					),
					'description' => __( 'Add posts, pages, etc. by title.', 'js_composer' ),
				),
				array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Display", "b" ),
					"param_name" => "display",
					"value" => $display
				)
			)
		) );
	}
}
add_action( 'vc_before_init', 'sh_pc_integrateWithVC' );

if( !function_exists( 'vc_autocomplete_insert_page_callback' ) )
{
	function vc_autocomplete_insert_page_callback( $search_string ) 
	{
		$query = $search_string;
		$data = array();
		$args = array(
			's' => $query,
			'post_type' => 'any',
		);
		$args['vc_search_by_title_only'] = true;
		$args['numberposts'] = - 1;
		if ( 0 === strlen( $args['s'] ) ) {
			unset( $args['s'] );
		}
		add_filter( 'posts_search', 'vc_search_by_title_only', 500, 2 );
		$posts = get_posts( $args );
		if ( is_array( $posts ) && ! empty( $posts ) ) {
			foreach ( $posts as $post ) {
				$data[] = array(
					'value' => $post->ID,
					'label' => $post->post_title,
					'group' => $post->post_type,
				);
			}
		}

		return $data;
	}
}
add_filter( 'vc_autocomplete_insert_page_callback', 'vc_autocomplete_insert_page_callback' );

if( !function_exists( 'b_post_custom_css' ) )
{
	function b_post_custom_css( $id = 0 )
	{
		/*wp_enqueue_script('ultimate-script');
		wp_enqueue_style('ultimate-style-min');
		wp_enqueue_script("ultimate-modal-all" );
		wp_enqueue_style("ultimate-modal-all" );*/
		$css = '';
		foreach( array( '_wpb_post_custom_css', '_wpb_shortcodes_custom_css' ) as $k )
		{
			$shortcodes_custom_css = get_post_meta( $id, $k, true );
			if ( ! empty( $shortcodes_custom_css ) ) 
			{
				$css .= strip_tags( $shortcodes_custom_css );
			}
		}

		do_action( 'b_put_css', $css );
	}
}
add_action( 'b_post_custom_css', 'b_post_custom_css' );

if( !function_exists( 'b_insert_pages_wrap_content' ) )
{
	function b_insert_pages_wrap_content( $content, $inserted_page, $attributes )
	{
		$id = $inserted_page->ID;
		do_action( 'b_post_custom_css', $id );
		return $content;
	}
}
add_filter( 'insert_pages_wrap_content', 'b_insert_pages_wrap_content', 10, 3 );

if( !function_exists( 'sh_b_integrateWithVC' ) )
{
	function sh_b_integrateWithVC() 
	{
		vc_map( array(
			"name" => __( "Breadcrumbs", "b" ),
			"base" => "wpseo_breadcrumb",
			"class" => "",
			"category" => __( "Content", "b"),
			"params" => array(
					
			)
		) );
	}
}
add_action( 'vc_before_init', 'sh_b_integrateWithVC' );

if( !function_exists( 'b_vc_text_separator_integrateWithVC' ) )
{
	function b_vc_text_separator_integrateWithVC() 
	{
		$values = array(
			'0px' => '0',
			'1px' => '',
			'2px' => '2',
			'3px' => '3',
			'4px' => '4',
			'5px' => '5',
			'6px' => '6',
			'7px' => '7',
			'8px' => '8',
			'9px' => '9',
			'10px' => '10',
		);
		$attributes = array(
			'type' => 'dropdown',
			'heading' => __( 'Border width', 'b' ),
			'param_name' => 'border_width',
			'value' => $values,
			'description' => __( 'Select border width (pixels).', 'b' ),
		);
		vc_add_param( 'vc_text_separator', $attributes );
	}
}
add_action( 'vc_before_init', 'b_vc_text_separator_integrateWithVC' );

if( !function_exists( 'b_compare_integrateWithVC' ) )
{
	function b_compare_integrateWithVC() 
	{
		vc_map( array(
			"name" => __( "Compare List", "b" ),
			"base" => "b_compare",
			"class" => "",
			"category" => __( "Content", "b"),
			"params" => array(
				
			)
		) );
	}
}
add_action( 'vc_before_init', 'b_compare_integrateWithVC' );

if( !function_exists( 'b_put_css' ) )
{
	function b_put_css( $css = '' )
	{
		if( empty( $css ) )
		{
			return;
		}
		$id = 'css-' . uniqid() . '-' . rand(0, 100);
		echo "<div id='{$id}' class='hidden' data-xtag='css'>{$css}</div>";
		echo "<script>
			var s = document.createElement('style');
			s.innerHTML = document.getElementById( '{$id}' ).innerHTML;
			document.getElementsByTagName('head')[0].appendChild(s);
		</script>";
	}
}
add_action( 'b_put_css', 'b_put_css' );

if( !function_exists( 'b_pslider_integrateWithVC' ) )
{
	function b_pslider_integrateWithVC() 
	{
		$params = array(
			array(
				"type" => "autocomplete",
				"holder" => "div",
				"class" => "",
				"heading" => __( "Category ID", "b" ),
				"param_name" => "cats",
				"value" => '',
				'settings' => array(
					'multiple' => false,
					'sortable' => true,
					'groups' => true,
				),
				'description' => esc_html__( 'Add Products by category id.', 'b' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Limit', 'b' ),
				'param_name' => 'limit',
				'value' => array(
					'-1' => '-1',
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
					'7' => '7',
					'8' => '8',
					'9' => '9',
					'10' => '10',
				),
				'description' => esc_html__( 'ie Display 5 product at time. By defoult value is -1 ie all', 'b' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Slide to scroll', 'b' ),
				'param_name' => 'slide_to_scroll',
				'value' => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
					'7' => '7',
					'8' => '8',
					'9' => '9',
					'10' => '10',
				),
				'description' => esc_html__( 'Display no of products in a slider', 'b' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Slide to show', 'b' ),
				'param_name' => 'slide_to_show',
				'value' => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
					'7' => '7',
					'8' => '8',
					'9' => '9',
					'10' => '10',
				),
				'description' => esc_html__( 'Controls number of products rotate at a time', 'b' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Dots', 'b' ),
				'param_name' => 'dots',
				'value' => array(
					'true' => 'true',
					'false' => 'false',
				),
				'description' => esc_html__( 'Hide/Show pagination', 'b' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Arrows', 'b' ),
				'param_name' => 'arrows',
				'value' => array(
					'true' => 'true',
					'false' => 'false',
				),
				'description' => esc_html__( 'Hide/Show arrows', 'b' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Autoplay', 'b' ),
				'param_name' => 'autoplay',
				'value' => array(
					'true' => 'true',
					'false' => 'false',
				),
				'description' => esc_html__( 'Hide/Show arrows', 'b' ),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Class', 'b' ),
				'param_name' => 'slider_cls',
				'value' => 'products',
				'description' => esc_html__( 'This parameter target the wooCommerce default class for product looping', 'b' ),
			)
		);
		$shortcodes = array(
			'products_slider' 				=> esc_html__( "Product Slider", "b" ),
			'bestselling_products_slider' 	=> esc_html__( "Best selling Product Slider", "b" ),
			'featured_products_slider' 		=> esc_html__( "Featured Product Slider", "b" ),
		);
		foreach ( $shortcodes as $base => $name )
		{
			vc_map( array(
				"name" => $name,
				"base" => $base,
				"class" => "",
				"category" => __( "WooCommerce", "b"),
				"params" => $params
			) );
		}
	}
}
add_action( 'vc_before_init', 'b_pslider_integrateWithVC' );

if( !function_exists( 'vc_autocomplete_products_cats_callback' ) )
{
	function vc_autocomplete_products_cats_callback( $search_string ) 
	{
		$query = $search_string;
		$data = array();
		$args = array(
			's' => $query,
			'taxonomy' => 'product_cat',
		);
		$cates = get_categories( $args );
		if ( is_array( $cates ) && ! empty( $cates ) ) {
			foreach ( $cates as $cate ) {
				$data[] = array(
					'value' => $cate->term_id,
					'label' => $cate->name,
					'group' => 'product_cat',
				);
			}
		}

		return $data;
	}
}
add_filter( 'vc_autocomplete_products_slider_cats_callback', 'vc_autocomplete_products_cats_callback' );
add_filter( 'vc_autocomplete_bestselling_products_slider_cats_callback', 'vc_autocomplete_products_cats_callback' );
add_filter( 'vc_autocomplete_featured_products_slider_cats_callback', 'vc_autocomplete_products_cats_callback' );

if( !function_exists( 'b_sslogin_integrateWithVC' ) )
{
	function b_sslogin_integrateWithVC() 
	{
		vc_map( array(
			"name" => esc_html__( "Social login", "b" ),
			"base" => "apsl-login-lite",
			"class" => "",
			"category" => esc_html__( "Content", "b"),
			"params" => array(
				
			)
		) );
	}
}
add_action( 'vc_before_init', 'b_sslogin_integrateWithVC' );

if( !function_exists( 'b_register_integrateWithVC' ) )
{
	function b_register_integrateWithVC() 
	{
		vc_map( array(
			"name" => esc_html__( "Register form", "b" ),
			"base" => "woocommerce_simple_registration",
			"class" => "",
			"category" => esc_html__( "Content", "b"),
			"params" => array(
				
			)
		) );
	}
}
add_action( 'vc_before_init', 'b_register_integrateWithVC' );








