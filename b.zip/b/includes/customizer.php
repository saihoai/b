<?php 


if( !function_exists( 'b_customizer_url' ) )
{
	function b_customizer_url()
	{
		return plugin_dir_url( __DIR__ ) . 'a/c/customizer.css';
	}
}

if( !function_exists( 'b_customizer_get_asset' ) )
{
	function b_customizer_get_asset( $k = '' )
	{
		$dir = untrailingslashit( plugin_dir_path( __DIR__ ) );
		$data = array(
			'colors' 		=> $dir . '/a/c/colors.css',
			'bg' 			=> $dir . '/a/c/bg.css',
			'header_image' 	=> $dir . '/a/c/header_image.css',
			'loader' 	=> $dir . '/a/c/loader.css',
		);
		return isset( $data[ $k ] ) ? $data[ $k ] : '';
	}
}
if( !function_exists( 'b_get_content' ) )
{
	function b_get_content( $path = '', $data = array() )
	{
		if( !file_exists( $path ) )
		{
			return '';
		}
		ob_start();
		extract( $data );
		include( $path );
		return ob_get_clean();
	}
}
if ( ! function_exists( 'b_sanitize' ) )
{
	function b_sanitize( $value ) 
	{
		return $value;
	}
}

if( !function_exists( 'b_customize_register' ) )
{
	function b_customize_register( $wp_customize )
	{
		$wp_customize->remove_control( 'custom_logo' );
		$wp_customize->get_setting( 'background_image' )->transport  = 'refresh';
		
		// Add header style setting and control.
		$wp_customize->add_setting( 'h_s', array(
			'default'           => 0,
			'sanitize_callback' => 'b_sanitize',
			'transport'         => 'refresh',
		) );

		$wp_customize->add_control( 'h_s', array(
			'label'    => esc_html__( 'Header', 'b' ),
			'type'  => 'dropdown-pages',
			'section'  => 'title_tagline',
			'priority' => 100,
		) );

		// Add page title setting and control.
		$wp_customize->add_setting( 'p_t', array(
			'default'           => 0,
			'sanitize_callback' => 'b_sanitize',
			'transport'         => 'refresh',
		) );

		$wp_customize->add_control( 'p_t', array(
			'label'    => esc_html__( 'Page title', 'b' ),
			'type'  => 'dropdown-pages',
			'section'  => 'title_tagline',
			'priority' => 100,
		) );

		// Add footer bottom setting and control.
		$wp_customize->add_setting( 'f_t', array(
			'default'           => 0,
			'sanitize_callback' => 'b_sanitize',
			'transport'         => 'refresh',
		) );

		$wp_customize->add_control( 'f_t', array(
			'label'    => esc_html__( 'Footer top', 'b' ),
			'type'  => 'dropdown-pages',
			'section'  => 'title_tagline',
			'priority' => 100,
		) );

		// Add footer setting and control.
		$wp_customize->add_setting( 'f', array(
			'default'           => 0,
			'sanitize_callback' => 'b_sanitize',
			'transport'         => 'refresh',
		) );

		$wp_customize->add_control( 'f', array(
			'label'    => esc_html__( 'Footer', 'b' ),
			'type'  => 'dropdown-pages',
			'section'  => 'title_tagline',
			'priority' => 100,
		) );

		// Add 404 setting and control.
		$wp_customize->add_setting( '404_s', array(
			'default'           => 0,
			'sanitize_callback' => 'b_sanitize',
			'transport'         => 'refresh',
		) );

		$wp_customize->add_control( '404_s', array(
			'label'    => esc_html__( '404', 'b' ),
			'type'  => 'dropdown-pages',
			'section'  => 'title_tagline',
			'priority' => 100,
		) );

		// Add loader setting and control.
		$wp_customize->add_setting( 'loader', array(
			'default'           => '',
			'sanitize_callback' => 'b_sanitize',
			'transport'         => 'refresh',
		) );

		$wp_customize->add_control( 'loader', array(
			'label'    => esc_html__( 'Loader', 'b' ),
			'type'  => 'select',
			'section'  => 'title_tagline',
			'choices' => array(
				'' => esc_html__( 'None' ),
				'barber-shop' => esc_html__( 'barber-shop' ),
				'big-counter' => esc_html__( 'big-counter' ),
				'bounce' => esc_html__( 'bounce' ),
				'center-atom' => esc_html__( 'center-atom' ),
				'center-circle' => esc_html__( 'center-circle' ),
				'center-radar' => esc_html__( 'center-radar' ),
				'center-simple' => esc_html__( 'center-simple' ),
				'corner-indicator' => esc_html__( 'corner-indicator' ),
				'fill-left' => esc_html__( 'fill-left' ),
				'flash' => esc_html__( 'flash' ),
				'flat-top' => esc_html__( 'flat-top' ),
				'loading-bar' => esc_html__( 'loading-bar' ),
				'material' => esc_html__( 'material' ),
				'minimal' => esc_html__( 'minimal' ),
			),
		) );

		$wp_customize->add_panel( 'b' , array(
		    'title'      => esc_html__( 'Blog Page', 'b' ),
		    'priority'   => 121,
		) );
		$wp_customize->add_section( 'b_g' , array(
		    'title'      => esc_html__( 'General', 'b' ),
		    'panel'   => 'b',
		) );

		// Add blog sidebar width setting and control.
		$wp_customize->add_setting( 'b_sb_w', array(
			'default'           => '3',
			'sanitize_callback' => 'b_sanitize',
			'transport'         => 'refresh',
		) );

		$wp_customize->add_control( 'b_sb_w', array(
			'label'    => esc_html__( 'Sidebar width', 'b' ),
			'type'  => 'select',
			'section'  => 'b_g',
			'choices' => array(
				'2' => '2/12',
				'3' => '3/12',
				'4' => '4/12',
				'5' => '5/12',
				'6' => '6/12',
			),
		) );

		// Add blog sidebar position setting and control.
		$wp_customize->add_setting( 'b_sb_p', array(
			'default'           => 'none',
			'sanitize_callback' => 'b_sanitize',
			'transport'         => 'refresh',
		) );

		$wp_customize->add_control( 'b_sb_p', array(
			'label'    => __( 'Sidebar position', 'b' ),
			'type'  => 'select',
			'section'  => 'b_g',
			'choices' => array(
				'none' => esc_html__( 'None', 'b' ),
				'left' => esc_html__( 'Left', 'b' ),
				'right' => esc_html__( 'Right', 'b' ),
			),
		) );

		$wp_customize->add_panel( 's' , array(
		    'title'      => esc_html__( 'Collection Page', 'b' ),
		    'priority'   => 121,
		) );
		$wp_customize->add_section( 's_g' , array(
		    'title'      => esc_html__( 'Sidebar', 'b' ),
		    'panel'   => 's',
		) );

		// Add blog sidebar width setting and control.
		$wp_customize->add_setting( 's_sb_w', array(
			'default'           => '3',
			'sanitize_callback' => 'b_sanitize',
			'transport'         => 'refresh',
		) );

		$wp_customize->add_control( 's_sb_w', array(
			'label'    => esc_html__( 'Sidebar width', 'b' ),
			'type'  => 'select',
			'section'  => 's_g',
			'choices' => array(
				'2' => '2/12',
				'3' => '3/12',
				'4' => '4/12',
				'5' => '5/12',
				'6' => '6/12',
			),
		) );

		// Add blog sidebar position setting and control.
		$wp_customize->add_setting( 's_sb_p', array(
			'default'           => 'none',
			'sanitize_callback' => 'b_sanitize',
			'transport'         => 'refresh',
		) );

		$wp_customize->add_control( 's_sb_p', array(
			'label'    => __( 'Sidebar position', 'b' ),
			'type'  => 'select',
			'section'  => 's_g',
			'choices' => array(
				'none' => esc_html__( 'None', 'b' ),
				'left' => esc_html__( 'Left', 'b' ),
				'right' => esc_html__( 'Right', 'b' ),
			),
		) );
	}
}
add_action( 'customize_register', 'b_customize_register', 11 );

if( !function_exists( 'b_loader_css' ) )
{
	function b_loader_css() 
	{
		
		$style 		= get_theme_mod( 'loader', '' );
		$color 		= get_theme_mod( 'header_textcolor', '' );

		// Don't do anything if the default color scheme is selected.
		if ( empty( $style ) ) {
			return;
		}
		if ( empty( $color ) ) {
			$color = 'c39a4a';
		}

		$data 	= array(
			'style' 		=> $style,
			'color' 		=> "#{$color}",
		);

		$css = b_get_content( b_customizer_get_asset( 'loader' ), $data );

		wp_enqueue_script( 'pace', 'https://cdnjs.cloudflare.com/ajax/libs/pace/1.0.2/pace.min.js', array(), '20160816', true );
		wp_enqueue_style( 'b-customizer', b_customizer_url() );
		wp_add_inline_style( 'b-customizer', $css );
	}
}
add_action( 'wp_enqueue_scripts', 'b_loader_css', 20 );

if( !function_exists( 'b_color_css' ) )
{
	function b_color_css() 
	{
		
		$active = get_theme_mod( 'header_textcolor', 'c39a4a' );

		$data 	= array(
			'color' => "#{$active}",
		);

		$css = b_get_content( b_customizer_get_asset( 'colors' ), $data );

		wp_enqueue_style( 'b-customizer', b_customizer_url() );
		wp_add_inline_style( 'b-customizer', $css );
	}
}
add_action( 'wp_enqueue_scripts', 'b_color_css', 300 );

if( !function_exists( 'b_bg_css' ) )
{
	function b_bg_css() 
	{
		
		$bg = get_theme_mod( 'background_image' );

		if( empty( $bg ) )
		{
			return false;
		}

		$data 	= array(
			'bg' => '',
		);

		$css = b_get_content( b_customizer_get_asset( 'bg' ), $data );

		wp_enqueue_style( 'b-customizer', b_customizer_url() );
		wp_add_inline_style( 'b-customizer', $css );
	}
}
add_action( 'wp_enqueue_scripts', 'b_bg_css', 20 );

























