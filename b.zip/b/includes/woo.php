<?php 
if( !function_exists( 'b_woo_adon_plugin_template' ) )
{
   function b_woo_adon_plugin_template( $template, $template_name, $template_path ) 
   {
	     global $woocommerce;
	     $_template = $template;
	     if ( ! $template_path ) 
	        $template_path = $woocommerce->template_url;
	 
	     $plugin_path  = untrailingslashit( plugin_dir_path( __DIR__ ) )  . '/t/woo/';
	 
	    // Look within passed path within the theme - this is priority
	    $template = locate_template(
	    array(
	      $template_path . $template_name,
	      $template_name
	    )
	   );
	 
	   if( ! $template && file_exists( $plugin_path . $template_name ) )
	    $template = $plugin_path . $template_name;
	 
	   if ( ! $template )
	    $template = $_template;

	   return $template;
	}
}
add_filter( 'woocommerce_locate_template', 'b_woo_adon_plugin_template', 1, 3 );

if( !function_exists( 'b_remove_woo_ex' ) )
{
	function b_remove_woo_ex()
	{
	    remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10);
	    remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
	    remove_action( 'woocommerce_after_shop_loop_item','wpb_wl_hook_quickview_content' );
	    remove_action( 'woocommerce_after_shop_loop_item','wpb_wl_hook_quickview_link', 11 );
	    remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
		remove_action( 'woocommerce_archive_description', 'woocommerce_product_archive_description', 10 );
	    remove_action( 'wp_footer', array( 'WC_List_Grid', 'gridlist_set_default_view' ) );
	}
}
add_action('template_redirect', 'b_remove_woo_ex' );

if( !function_exists( 'b_woocommerce_show_page_title' ) )
{
	function b_woocommerce_show_page_title()
	{
		return false;
	}
}
add_filter( 'woocommerce_show_page_title', 'b_woocommerce_show_page_title' );

if( !function_exists( 'b_woocommerce_after_shop_loop_item_title' ) )
{
	function b_woocommerce_after_shop_loop_item_title()
	{
		echo '<div class="post_excerpt">' . apply_filters( 'woocommerce_short_description', get_the_excerpt() ) . '</div>';
	}
}
add_action( 'woocommerce_after_shop_loop_item_title', 'b_woocommerce_after_shop_loop_item_title', 15 );

if( !function_exists( 'b_before_topbar_woocommerce' ) )
{
	function b_before_topbar_woocommerce()
	{
		echo '<div class="s-toolbar">';
	}
}
add_action( 'woocommerce_before_shop_loop', 'b_before_topbar_woocommerce', 5 );

if( !function_exists( 'b_after_topbar_woocommerce' ) )
{
	function b_after_topbar_woocommerce()
	{
		echo '</div>';
	}
}
add_action( 'woocommerce_before_shop_loop', 'b_after_topbar_woocommerce', 1000 );

if( !function_exists( 'b_woocommerce_after_add_to_cart_button' ) )
{
	function b_woocommerce_after_add_to_cart_button()
	{
		echo '<div class="yith_wcwl_add_to_wishlist">' . do_shortcode( '[yith_wcwl_add_to_wishlist]' ) . '</div>';
	}
}
add_action( 'woocommerce_after_add_to_cart_button', 'b_woocommerce_after_add_to_cart_button' );

if( !function_exists( 'b_woo_social' ) )
{
	function b_woo_social()
	{
		$url = get_the_permalink();
		$title = esc_url( get_the_title() );
		$output = "<div class='post-social'>";
			$output .= "<label>". __( 'Share Link:', 'b' ) ."</label>";
			$output .= "<a href='https://www.facebook.com/sharer/sharer.php?u={$url}'><i class='fa fa-facebook'></i></a>";
			$output .= "<a href='https://twitter.com/home?status={$url}'><i class='fa fa-twitter'></i></a>";
			$output .= "<a href='https://plus.google.com/share?url={$url}'><i class='fa fa-google-plus'></i></a>";
			$output .= "<a href='https://www.linkedin.com/shareArticle?mini=true&url={$url}&title={$title}&summary=&source='><i class='fa fa-linkedin'></i></a>";
			$output .= "<a href='https://pinterest.com/pin/create/button/?url={$url}&media=&description='><i class='fa fa-pinterest'></i></a>";
		$output .= "</div>";
		echo $output;
	}
}
add_action( 'woocommerce_share', 'b_woo_social' );

if( !function_exists( 'b_yith_wcwl_locate_template' ) )
{
	function b_yith_wcwl_locate_template( $located, $path )
	{
		$plugin_path  = untrailingslashit( plugin_dir_path( __DIR__ ) )  . '/t/wishlist/';
		return $plugin_path . $path;
	}
}
add_filter( 'yith_wcwl_locate_template', 'b_yith_wcwl_locate_template', 20, 2 );

if( !function_exists( 'b_woocommerce_steps' ) )
{
	function b_woocommerce_steps()
	{
		wc_get_template( 'global/steps.php' );
	}
}
add_action( 'woocommerce_before_cart', 'b_woocommerce_steps', 5 );
add_action( 'woocommerce_before_cart_empty', 'b_woocommerce_steps', 5 );
add_action( 'woocommerce_before_checkout_form', 'b_woocommerce_steps', 5 );
add_action( 'woocommerce_before_thankyou', 'b_woocommerce_steps', 5 );

if( !function_exists( 'b_woocommerce_add_to_cart_fragments' ) )
{
	function b_woocommerce_add_to_cart_fragments( $list = array() )
	{
		if( !is_array( $list ) )
		{
			$list = array();
		}
		$list[ '.btn-cart .ult-dual-btn-2 .text-btn' ] = '<span class="text-btn ult-dual-button-title">' . wp_filter_nohtml_kses( WC()->cart->get_cart_subtotal() ) . '</span>';
		$list[ '.btn-s-cart .middle-inner' ] = '<span class="middle-inner"  >' . count( WC()->cart->get_cart() ) . '</span>';
		return $list;
	}
}
add_filter( 'woocommerce_add_to_cart_fragments', 'b_woocommerce_add_to_cart_fragments' );

if( !function_exists( 'b_yith_wcwl_product_added_to_wishlist_message' ) )
{
	function b_yith_wcwl_product_added_to_wishlist_message( $text = '' )
	{
		if( function_exists( 'yith_wcwl_count_all_products' ) )
		{
			$text .= '<span class="c hidden">' . yith_wcwl_count_all_products() . '</span>';
		}
		return $text;
	}
}
add_filter( 'yith_wcwl_product_added_to_wishlist_message', 'b_yith_wcwl_product_added_to_wishlist_message' );

if( !function_exists( 'b_woocommerce_template_loop_product_title' ) )
{
	function b_woocommerce_template_loop_product_title()
	{
		echo '<h3 class="woocommerce-loop-product__title">' . get_the_title() . '</h3>';
	}
}
add_action( 'woocommerce_shop_loop_item_title', 'b_woocommerce_template_loop_product_title', 20 );

if( !function_exists( 'alg_wc_product_countdown' ) )
{
	function b_alg_wc_product_countdown( $postion = 'woocommerce_after_shop_loop_item_title', $prioriy = 200 )
	{
		return 'woocommerce_after_shop_loop_item';
	}
}
add_filter( 'alg_wc_product_countdown', 'b_alg_wc_product_countdown' );

if( !function_exists( 'b_options_alg_wc_product_countdown_format' ) )
{
	function b_options_alg_wc_product_countdown_format( $v, $k )
	{
		if( $k != 'alg_wc_product_countdown_format' )
		{
			return false;
		}
		return '%s';
	}
}
add_filter( 'option_alg_wc_product_countdown_format', 'b_options_alg_wc_product_countdown_format', 2, 1000 );

if( !function_exists( 'b_options_alg_wc_product_countdown_format_human_time_diff' ) )
{
	function b_options_alg_wc_product_countdown_format_human_time_diff( $v, $k )
	{
		if( $k != 'alg_wc_product_countdown_format_human_time_diff' )
		{
			return false;
		}
		return 'yes';
	}
}
add_filter( 'option_alg_wc_product_countdown_format_human_time_diff', 'b_options_alg_wc_product_countdown_format_human_time_diff', 2, 1000 );

if( !function_exists( 'b_human_time_diff' ) )
{
	function b_human_time_diff( $since, $diff, $from, $time )
	{
		$flag = isset( $_POST[ 'action' ] ) && $_POST[ 'action' ] == 'alg_product_countdown';

		if( !$flag )
		{
			return $since;
		}
		
		$days = floor($time / (60 * 60 * 24));
		$time -= $days * (60 * 60 * 24);

		$hours = floor($time / (60 * 60));
		$time -= $hours * (60 * 60);

		$minutes = floor($time / 60);
		$time -= $minutes * 60;

		$seconds = floor($time);
		$time -= $seconds;

		return "
			<span class='d' data-label='" . esc_html__( 'Days', 'd' ) . "'><span class='item'>{$days}</span></span>
			<span class='h' data-label='" . esc_html__( 'Hours', 'd' ) . "'><span class='item'>{$hours}</span></span>
			<span class='m' data-label='" . esc_html__( 'Mins', 'd' ) . "'><span class='item'>{$minutes}</span></span>
			<span class='s' data-label='" . esc_html__( 'Secs', 'd' ) . "'><span class='item'>{$seconds}</span></span>
			<span class='btn-shopnow'><span>" . esc_html__( 'Shop now', 'd' ) . "</span></span>
		";
	}
}
add_filter( 'human_time_diff', 'b_human_time_diff', 4, 1000 );

if( !function_exists( 'b_wc_get_template_zoom' ) )
{
	function b_wc_get_template_zoom( $located, $template_name, $args, $template_path, $default_path )
	{
		if( preg_match( '/single-product\/product-image-magnifier\.php|single-product\/product-thumbnails-magnifier\.php/', $located ) )
		{
			$located = str_replace( '/yith-essential-kit-for-woocommerce-1/modules/', '/', $located );
			$located = str_replace( '/yith-woocommerce-zoom-magnifier/templates/single-product', '/b/t/pzoom', $located );
			
		}
		return $located;
	}
}
add_filter( 'wc_get_template', 'b_wc_get_template_zoom', 10, 5 );

if( !function_exists( 'b_wc_get_template_variant' ) )
{
	function b_wc_get_template_variant( $located, $template_name, $args, $template_path, $default_path )
	{
		if( preg_match( '/variable-wccl\.php/', $located ) )
		{
			$located = str_replace( '/yith-essential-kit-for-woocommerce-1/modules/', '/', $located );
			$located = str_replace( '/yith-woocommerce-colors-labels-variations/templates/single-product', '/b/t/pvariant', $located );
			
		}
		return $located;
	}
}
add_filter( 'wc_get_template', 'b_wc_get_template_variant', 10, 5 );

if( !function_exists( 'b_woocommerce_archive_description' ) )
{
	function b_woocommerce_archive_description()
	{
		if ( is_post_type_archive( 'product' ) && 0 === absint( get_query_var( 'paged' ) ) ) {
			$shop_page   = get_post( wc_get_page_id( 'shop' ) );
			if ( $shop_page ) {
				do_action( 'b_post_custom_css', $shop_page->ID );
				$description = apply_filters( 'the_content', $shop_page->post_content );
				if ( $description ) {
					echo '<div class="page-description">' . $description . '</div>';
				}
			}
		}
	}
}
add_action( 'b_row_start', 'b_woocommerce_archive_description' );

function b_gridlist_set_default_view() {
	$default = get_option( 'wc_glt_default' );
	if( isset( $_GET[ 'v' ] ) )
	{
		if( $_GET[ 'v' ] == 'g' )
		{
			$default = 'grid';
		}
		elseif( $_GET[ 'v' ] == 'l' )
		{
			$default = 'list';	
		}
		echo "<script>
				window.jQuery && (function( $ ) {
					$.cookie && $.cookie( 'gridcookie', '{$default}' )
					$( 'ul.products' ).addClass( '{$default}' );
		    		$( '.gridlist-toggle #{$default}' ).addClass( 'active' );
				} )( jQuery );
		</script>";
		return false;
	}
	echo "<script>
		window.jQuery && (function( $ ) {
			if ($.cookie &&  $.cookie( 'gridcookie' ) == null) {
				$( 'ul.products' ).addClass( '{$default}' );
	    		$( '.gridlist-toggle #{$default}' ).addClass( 'active' );
	    	}
		} )( jQuery );
	</script>";
}
add_action( 'wp_footer', 'b_gridlist_set_default_view' );












































