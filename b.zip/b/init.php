<?php
/*
Plugin Name:    B
Description:    Output configs using a simple shortcode.
Author:         Saihoai
Version:        0.1.0
Text Domain:    b
*/


require_once __DIR__ . '/includes/vc_shortcodes.php';
require_once __DIR__ . '/includes/woo.php';
require_once __DIR__ . '/includes/shortcodes.php';
require_once __DIR__ . '/includes/theme.php';
require_once __DIR__ . '/includes/customizer.php';
require_once( __DIR__ . '/includes/tool.php' );