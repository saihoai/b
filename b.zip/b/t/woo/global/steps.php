<div class="steps">
	<div class="step first<?php if( is_cart() ) : ?> active<?php endif; ?>">
		<div class="text"><span><?php echo esc_html_e( 'Shopping Cart', 'woocommerce' ); ?></span></div>
	</div>
	<div class="step<?php if( is_checkout() && !is_wc_endpoint_url( 'order-received' ) ) : ?> active<?php endif; ?>">
		<div class="text"><span><?php echo esc_html_e( 'Check Out', 'woocommerce' ); ?></span></div>
	</div>
	<div class="step<?php if( is_wc_endpoint_url( 'order-received' ) ) : ?> active<?php endif; ?>">
		<div class="text"><span><?php echo esc_html_e( 'Order Completed', 'woocommerce' ); ?></span></div>
	</div>
</div>
