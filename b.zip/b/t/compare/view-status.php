<?php
$availability = $product->get_availability();
if ( empty( $availability['availability'] ) ) 
{
    $availability['availability'] = __( 'In stock', 'yith-woocommerce-compare' );
}
echo sprintf( '<span class="%s">%s</span>', esc_attr( $availability['class'] ), esc_html( $availability['availability'] ) );
?>