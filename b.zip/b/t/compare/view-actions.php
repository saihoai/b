<div class="btn-action-group">
	<?php if( function_exists( 'woocommerce_template_loop_add_to_cart' ) ) : ?>
		<?php woocommerce_template_loop_add_to_cart(); ?>
	<?php else : ?>
		<?php wc_get_template( 'loop/add-to-cart.php' ); ?>
	<?php endif ?>
	<a href="<?php echo add_query_arg( 'redirect', 'view', $yith_woocompare->obj->remove_product_url( get_the_ID() ) ) ?>" data-product_id="<?php echo get_the_ID(); ?>" class="remove"><?php esc_html_e( 'Remove', 'b' ) ?></a>
</div>