<div class="woocommerce">
	<div class="compare-list compare-size-normal">
		<table class="table table-reponsive">
			<tbody>
				<?php foreach( $fields as $k => $v ) : ?>
					<tr class="field-<?php echo $k; ?>">
						<th><?php echo $v; ?></th>
						<td>-</td>
						<td>-</td>
						<td>-</td>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
</div>
