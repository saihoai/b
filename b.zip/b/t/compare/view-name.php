<a href="<?php echo esc_url( get_permalink( apply_filters( 'woocommerce_in_cart_product', $product->get_ID() ) ) ) ?>">
    <?php echo $product->get_image() ?>
    <span class="name"><?php echo apply_filters( 'woocommerce_in_cartproduct_obj_title', $product->get_title(), $product ) ?></span>
</a>