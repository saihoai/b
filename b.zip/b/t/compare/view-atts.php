<?php 
$html = '';
if ( taxonomy_exists( $k ) ) {
    $terms = get_the_terms( $product->get_ID(), $k );
    $args = array( 'selected' => '' );
    $swatch_attribute = array();
    if ( ! empty( $terms ) ) {
        
        $attr_k = substr( $k, 3 );
		$attr_k = $wpdb->get_row( "SELECT * FROM " . $wpdb->prefix . "woocommerce_attribute_taxonomies WHERE attribute_name = '{$attr_k}'" ); 
        if( $attr_k )
        {
    		foreach ( $terms as $term ) 
    		{
    			$html .= apply_filters( 'tawcvs_swatch_html', '', $term, $attr_k, $args );
    		}
    	}
    }
}
?>
<?php if( !empty( $html ) ) : ?>
	<?php echo $html; ?>
<?php else : ?>
	<?php echo $product->fields[ $k ]; ?>
<?php endif ?>