<style>
@import url("<?php echo YITH_WOOCOMPARE_URL . 'assets/css/jquery.dataTables.css'; ?>");
</style>
<script><?php include( dirname( YITH_WOOCOMPARE_FILE ) . '/assets/js/jquery.dataTables.min.js' ); ?></script>
<script><?php include( dirname( YITH_WOOCOMPARE_FILE ) . '/assets/js/FixedColumns.min.js' ); ?></script>
<div class="woocommerce">
	<div class="compare-list compare-size-<?php echo( count( $products ) > 3 ? 'large' : 'normal' )?>">
		<table class="table table-reponsive">
			<?php foreach( $fields as $k => $v ) : ?>
				<tr class="field-<?php echo $k; ?>">
					<th><?php echo $v; ?><div class="fixed-th"></div></th>
					<?php foreach( $products as $p ) : ?>
						<?php global $product; ?>
						<?php $product = $p; ?>
					<td>
						<?php $tpl = "{$plugin_path}view-{$k}.php"; ?>
						<?php if( in_array( $k, $att_keys ) ) : ?>
							<?php $tpl = "{$plugin_path}view-atts.php"; ?>
						<?php endif ?>
						<?php require( $tpl ); ?>
					</td>	
					<?php endforeach; ?>
				</tr>
			<?php endforeach ?>
		</table>
	</div>
</div>
