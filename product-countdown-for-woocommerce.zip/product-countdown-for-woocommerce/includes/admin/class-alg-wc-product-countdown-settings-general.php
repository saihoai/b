<?php
/**
 * Product Time Countdown for WooCommerce - General Section Settings
 *
 * @version 1.2.0
 * @since   1.0.0
 * @author  Algoritmika Ltd.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'Alg_WC_Product_Countdown_Settings_General' ) ) :

class Alg_WC_Product_Countdown_Settings_General extends Alg_WC_Product_Countdown_Settings_Section {

	/**
	 * Constructor.
	 *
	 * @version 1.0.0
	 * @since   1.0.0
	 */
	function __construct() {
		$this->id   = '';
		$this->desc = __( 'General', 'product-countdown-for-woocommerce' );
		parent::__construct();
	}

	/**
	 * add_settings.
	 *
	 * @version 1.2.0
	 * @since   1.0.0
	 */
	function add_settings( $settings ) {
		$settings = array_merge(
			array(
				array(
					'title'     => __( 'Product Time Countdown Options', 'product-countdown-for-woocommerce' ),
					'type'      => 'title',
					'id'        => 'alg_wc_product_countdown_options',
				),
				array(
					'title'     => __( 'WooCommerce Product Time Countdown', 'product-countdown-for-woocommerce' ),
					'desc'      => '<strong>' . __( 'Enable', 'product-countdown-for-woocommerce' ) . '</strong>',
					'desc_tip'  => __( 'Product Time Countdown for WooCommerce.', 'product-countdown-for-woocommerce' ),
					'id'        => 'alg_wc_product_countdown_enabled',
					'default'   => 'yes',
					'type'      => 'checkbox',
				),
				array(
					'type'      => 'sectionend',
					'id'        => 'alg_wc_product_countdown_options',
				),
				array(
					'title'     => __( 'General Options', 'product-countdown-for-woocommerce' ),
					'type'      => 'title',
					'id'        => 'alg_wc_product_countdown_general_options',
				),
				array(
					'title'     => __( 'Template', 'product-countdown-for-woocommerce' ),
					'id'        => 'alg_wc_product_countdown_format',
					'default'   => '%s left',
					'type'      => 'text',
					'css'       => 'min-width:99%;',
				),
				array(
					'title'     => __( 'Human Readable Format', 'product-countdown-for-woocommerce' ),
					'desc'      => __( 'Enable', 'product-countdown-for-woocommerce' ),
					'desc_tip'  => sprintf( __( 'Will use %s function to display time.', 'product-countdown-for-woocommerce' ),
						'<a target="_blank" href="https://codex.wordpress.org/Function_Reference/human_time_diff"><code>human_time_diff()</code></a>' ),
					'id'        => 'alg_wc_product_countdown_format_human_time_diff',
					'default'   => 'no',
					'type'      => 'checkbox',
				),
				array(
					'title'     => __( 'Style', 'product-countdown-for-woocommerce' ),
					'id'        => 'alg_wc_product_countdown_style',
					'default'   => 'font-size: xx-large; font-weight: bold;',
					'type'      => 'text',
					'css'       => 'min-width:99%;',
				),
				array(
					'title'     => __( 'Update Rate', 'product-countdown-for-woocommerce' ),
					'desc'      => __( 'ms', 'product-countdown-for-woocommerce' ),
					'id'        => 'alg_wc_product_countdown_update_rate_ms',
					'default'   => 1000,
					'type'      => 'number',
					'custom_attributes' => array( 'min' => 0 ),
				),
				array(
					'type'      => 'sectionend',
					'id'        => 'alg_wc_product_countdown_general_options',
				),
				array(
					'title'     => __( 'Position Options', 'product-countdown-for-woocommerce' ),
					'desc'      =>
						sprintf( __( 'You will need <a href="%s" target="_blank">Product Time Countdown for WooCommerce Pro</a> plugin to change this section\'s settings.', 'product-countdown-for-woocommerce' ),
							'https://wpcodefactory.com/item/product-time-countdown-woocommerce/' ) . ' ' .
						sprintf( __( 'In Pro version you can also use %s shortcode to display the counter.', 'product-countdown-for-woocommerce' ),
							'<code>' . '[product_time_counter]' . '</code>' ),
					'type'      => 'title',
					'id'        => 'alg_wc_product_countdown_position_options',
				),
				array(
					'title'     => __( 'Position on Single Product Page', 'product-countdown-for-woocommerce' ),
					'id'        => 'alg_wc_product_countdown_position',
					'default'   => 'woocommerce_single_product_summary',
					'type'      => 'select',
					'options'   => array(
						'disable'                                   => __( 'Do not add', 'product-countdown-for-woocommerce' ),
						'woocommerce_before_single_product'         => __( 'Before single product', 'product-countdown-for-woocommerce' ),
						'woocommerce_before_single_product_summary' => __( 'Before single product summary', 'product-countdown-for-woocommerce' ),
						'woocommerce_single_product_summary'        => __( 'Inside single product summary', 'product-countdown-for-woocommerce' ),
						'woocommerce_after_single_product_summary'  => __( 'After single product summary', 'product-countdown-for-woocommerce' ),
						'woocommerce_after_single_product'          => __( 'After single product', 'product-countdown-for-woocommerce' ),
						'woocommerce_before_add_to_cart_form'       => __( 'Before add to cart form', 'product-countdown-for-woocommerce' ),
						'woocommerce_before_add_to_cart_button'     => __( 'Before add to cart button', 'product-countdown-for-woocommerce' ),
						'woocommerce_after_add_to_cart_button'      => __( 'After add to cart button', 'product-countdown-for-woocommerce' ),
						'woocommerce_after_add_to_cart_form'        => __( 'After add to cart form', 'product-countdown-for-woocommerce' ),
					),
					'custom_attributes' => apply_filters( 'alg_wc_product_countdown', array( 'disabled' => 'disabled' ), 'settings' ),
				),
				array(
					'title'     => __( 'Position Priority', 'product-countdown-for-woocommerce' ),
					'desc_tip'  => __( 'Change this if you want to move the timer inside the Position.', 'product-countdown-for-woocommerce' ) . ' ' .
							__( 'Existing priorities:', 'product-countdown-for-woocommerce' ) . '<br>' .
							__( '<em>Before single product:</em><br>notices - 10.', 'product-countdown-for-woocommerce' ) . '<br>' .
							__( '<em>Before single product summary:</em><br>sale flash - 10,<br>product images - 20.', 'product-countdown-for-woocommerce' ) . '<br>' .
							__( '<em>Inside single product summary:</em><br>title - 5,<br>rating - 10,<br>price - 10,<br>excerpt - 20,<br>add to cart - 30,<br>meta - 40,<br>sharing - 50.', 'product-countdown-for-woocommerce' ) . '<br>' .
							__( '<em>After single product summary:</em><br>product data tabs - 10,<br>upsell - 15,<br>related products - 20.', 'product-countdown-for-woocommerce' ),
					'id'        => 'alg_wc_product_countdown_position_priority',
					'default'   => 10,
					'type'      => 'number',
					'custom_attributes' => apply_filters( 'alg_wc_product_countdown', array( 'disabled' => 'disabled' ), 'settings' ),
				),
				array(
					'title'     => __( 'Position on Archive Pages', 'product-countdown-for-woocommerce' ),
					'id'        => 'alg_wc_product_countdown_loop_position',
					'default'   => 'disable',
					'type'      => 'select',
					'options'   => array(
						'disable'                                 => __( 'Do not add', 'product-countdown-for-woocommerce' ),
						'woocommerce_before_shop_loop_item'       => __( 'Before product', 'product-countdown-for-woocommerce' ),
						'woocommerce_before_shop_loop_item_title' => __( 'Before product title', 'product-countdown-for-woocommerce' ),
						'woocommerce_shop_loop_item_title'        => __( 'Inside product title', 'product-countdown-for-woocommerce' ),
						'woocommerce_after_shop_loop_item_title'  => __( 'After product title', 'product-countdown-for-woocommerce' ),
						'woocommerce_after_shop_loop_item'        => __( 'After product', 'product-countdown-for-woocommerce' ),
					),
					'custom_attributes' => apply_filters( 'alg_wc_product_countdown', array( 'disabled' => 'disabled' ), 'settings' ),
				),
				array(
					'title'     => __( 'Position Priority', 'product-countdown-for-woocommerce' ),
					'desc_tip'  => __( 'Change this if you want to move the timer inside the Position.', 'product-countdown-for-woocommerce' ),
					'id'        => 'alg_wc_product_countdown_loop_position_priority',
					'default'   => 10,
					'type'      => 'number',
					'custom_attributes' => apply_filters( 'alg_wc_product_countdown', array( 'disabled' => 'disabled' ), 'settings' ),
				),
				array(
					'type'      => 'sectionend',
					'id'        => 'alg_wc_product_countdown_position_options',
				),
			),
			$settings
		);
		return $settings;
	}

}

endif;

return new Alg_WC_Product_Countdown_Settings_General();
