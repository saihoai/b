<?php
/**
 * Product Time Countdown for WooCommerce - Core Class
 *
 * @version 1.2.0
 * @since   1.0.0
 * @author  Algoritmika Ltd.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'Alg_WC_Product_Countdown_Core' ) ) :

class Alg_WC_Product_Countdown_Core {

	/**
	 * Constructor.
	 *
	 * @version 1.2.0
	 * @since   1.0.0
	 */
	function __construct() {

		if ( 'yes' === get_option( 'alg_wc_product_countdown_enabled', 'yes' ) ) {

			require_once( 'admin/class-alg-wc-product-countdown-metaboxes.php' );

			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles_and_scripts' ) );

			add_action( 'wp_ajax_alg_product_countdown',        array( $this, 'ajax_alg_product_countdown' ) );
			add_action( 'wp_ajax_nopriv_alg_product_countdown', array( $this, 'ajax_alg_product_countdown' ) );

			if ( 'disable' != ( $position = apply_filters( 'alg_wc_product_countdown', 'woocommerce_single_product_summary', 'value_position' ) ) ) {
				add_action( $position, array( $this, 'add_counter_to_frontend' ), apply_filters( 'alg_wc_product_countdown', 10, 'value_position_priority' ) );
			}

			if ( 'disable' != ( $position = apply_filters( 'alg_wc_product_countdown', 'disable', 'value_loop_position' ) ) ) {
				add_action( $position, array( $this, 'add_counter_to_frontend' ), apply_filters( 'alg_wc_product_countdown', 10, 'value_loop_position_priority' ) );
			}

			add_action( 'woocommerce_is_purchasable', array( $this, 'check_date' ), PHP_INT_MAX, 2 );

			if ( apply_filters( 'alg_wc_product_countdown', false, 'shortcode' ) ) {
				add_shortcode( 'product_time_counter', array( $this, 'get_counter_shortcode' ) );
			}
		}
	}

	/**
	 * get_time_left_formatted.
	 *
	 * @version 1.0.0
	 * @since   1.0.0
	 * @todo    (maybe) time ended: set stock to 0
	 * @todo    (maybe) time ended: remove sale
	 * @todo    (maybe) time ended: customizable message
	 * @todo    (maybe) time ended: hide add to cart buttons (and on archives - replace with "read more") - instead of previously used `location.reload()`
	 * @todo    (maybe) time format: customizable upper time period (years?, months?, weeks?, days, hours*, minutes, seconds)
	 * @todo    (maybe) time format: customizable format (e.g. `HH:MM:SS` or `HH hours, MM minutes and SS seconds`)
	 */
	function get_time_left_formatted( $product_id ) {
		if ( ( $result = $this->get_time_left( $product_id ) ) <= 0 ) {
			return '';
		} else {
			if ( 'no' === get_option( 'alg_wc_product_countdown_format_human_time_diff', 'no' ) ) {
				$hours    = floor( $result / 3600 );
				$minutes  = floor( ( $result / 60 ) % 60 );
				$seconds  = $result % 60;
				$the_time = sprintf( '%02d:%02d:%02d', $hours, $minutes, $seconds );
			} else {
				$the_time = human_time_diff( 0, $result );
			}
			return sprintf( get_option( 'alg_wc_product_countdown_format', '%s left' ), $the_time );
		}
	}

	/**
	 * get_time_left.
	 *
	 * @version 1.0.0
	 * @since   1.0.0
	 */
	function get_time_left( $product_id ) {
		$finish_time  = get_post_meta( $product_id, '_' . 'alg_product_countdown_date', true ) . ' ' .
			get_post_meta( $product_id, '_' . 'alg_product_countdown_time', true );
		$finish_time  = strtotime( $finish_time );
		$current_time = (int) current_time( 'timestamp' );
		return ( $finish_time - $current_time );
	}

	/**
	 * ajax_alg_product_countdown.
	 *
	 * @version 1.2.0
	 * @since   1.0.0
	 */
	function ajax_alg_product_countdown() {
		if ( isset( $_POST['product_ids'] ) && is_array( $_POST['product_ids'] ) ) {
			$result = array();
			foreach ( $_POST['product_ids'] as $product_id ) {
				if ( 'yes' === get_post_meta( $product_id, '_' . 'alg_product_countdown_enabled', true ) ) {
					$result[ $product_id ] = $this->get_time_left_formatted( $product_id );
				}
			}
			if ( ! empty( $result ) ) {
				echo json_encode( $result );
			}
		}
		die();
	}

	/**
	 * check_date.
	 *
	 * @version 1.2.0
	 * @since   1.0.0
	 */
	function check_date( $purchasable, $_product ) {
		$_product_id = ( version_compare( get_option( 'woocommerce_version', null ), '3.0.0', '<' ) ?
			$_product->id :
			( $_product->is_type( 'variation' ) ? $_product->get_parent_id() : $_product->get_id() )
		);
		if (
			'yes'             === get_post_meta( $_product_id, '_' . 'alg_product_countdown_enabled', true ) &&
			'disable_product' === get_post_meta( $_product_id, '_' . 'alg_product_countdown_action',  true ) &&
			$this->get_time_left( $_product_id ) <= 0
		) {
			return false;
		}
		return $purchasable;
	}

	/**
	 * get_counter_html.
	 *
	 * @version 1.2.0
	 * @since   1.2.0
	 */
	function get_counter_html( $product_id = 0 ) {
		if ( 0 == $product_id ) {
			$product_id = get_the_ID();
		}
		if ( 'yes' === get_post_meta( $product_id, '_' . 'alg_product_countdown_enabled', true ) ) {
			if ( $this->get_time_left( $product_id ) > 0 ) {
				return '<span ' .
					'class="alg_product_countdown" ' .
					'data-product_id="' . $product_id . '" ' .
					'style="'      . get_option( 'alg_wc_product_countdown_style', 'font-size: xx-large; font-weight: bold;' ). '"' .
				'>' . '</span>';
			}
		}
	}

	/**
	 * add_counter_to_frontend.
	 *
	 * @version 1.2.0
	 * @since   1.0.0
	 */
	function add_counter_to_frontend() {
		echo $this->get_counter_html();
	}

	/**
	 * get_counter_shortcode.
	 *
	 * @version 1.2.0
	 * @since   1.2.0
	 */
	function get_counter_shortcode( $atts ) {
		$product_id = ( isset( $atts['product_id'] ) ? $atts['product_id'] : 0 );
		return $this->get_counter_html();
	}

	/**
	 * enqueue_styles_and_scripts.
	 *
	 * @version 1.2.0
	 * @since   1.0.0
	 * @todo    (maybe) simple js (i.e. no ajax)
	 * @todo    (maybe) pass initial `time_left` to js (so first update will happen faster, i.e. without first call to ajax)
	 */
	function enqueue_styles_and_scripts() {
		wp_enqueue_script( 'simple-countdown-js',
			untrailingslashit( plugin_dir_url( __FILE__ ) ) . '/js/simple-countdown.js',
			array( 'jquery' ),
			alg_wc_product_countdown()->version,
			true
		);
		wp_localize_script(
			'simple-countdown-js',
			'alg_data_countdown',
			array(
				'update_rate_ms' => get_option( 'alg_wc_product_countdown_update_rate_ms', 1000 ),
				'ajax_url'       => admin_url( 'admin-ajax.php' ),
			)
		);
	}

}

endif;

return new Alg_WC_Product_Countdown_Core();
