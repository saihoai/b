=== Product Time Countdown for WooCommerce ===
Contributors: algoritmika,anbinder
Tags: woocommerce,product,countdown,time,product time countdown,product countdown,time countdown,time counter
Requires at least: 4.4
Tested up to: 4.8
Stable tag: 1.2.0
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Plugin lets you add live time counter to any WooCommerce product. After time ends, product can be automatically disabled.

== Description ==

Product time countdown for WooCommerce.

= Feedback =
* We are open to your suggestions and feedback. Thank you for using or trying out one of our plugins!

== Installation ==

1. Upload the entire 'product-countdown-for-woocommerce' folder to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Start by visiting plugin settings at WooCommerce > Settings > Product Time Countdown.

== Changelog ==

= 1.2.0 - 22/07/2017 =
* Dev - WooCommerce v3 compatibility - Product ID.
* Dev - "Position on Archive Pages" options added.
* Dev - Option to disable counter on single product page added.
* Dev - `[product_time_counter]` shortcode added.
* Dev - "Update Rate" option added.
* Dev - "Human Readable Format" option added.
* Dev - More positions added to "Position on Single Product Page".
* Dev - Admin settings - Input types changed to `date` and `time` (instead of simple `text`).
* Dev - `location.reload()` removed from JS (on time ended).
* Dev - "Reset Section Settings" option added.
* Dev - Autoloading plugin options.
* Dev - Plugin renamed from "Product Countdown" to "Product Time Countdown".
* Dev - Link updated from http://coder.fm to https://wpcodefactory.com.
* Dev - Plugin header ("Text Domain" etc.) updated.

= 1.1.0 - 14/02/2017 =
* Fix - `load_plugin_textdomain` moved to constructor.
* Dev - Language (POT) file uploaded.
* Dev - Autoload set to `no` in `add_option`.
* Dev - "Position on Single Product Page" and "Position Priority" options added.
* Tweak - Tags updated.

= 1.0.0 - 24/11/2016 =
* Initial Release.

== Upgrade Notice ==

= 1.0.0 =
This is the first release of the plugin.
